<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Create extends Controller
{
    public function Create()
    {
        return 'Ini Halaman Create';
    }
}

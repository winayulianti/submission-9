<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UsersController extends Controller
{
    public function view_form_user(){
        $data['nama']= 'Jeonghan';
        $data['nim']= '100495';
        $data['prodi']= 'IFSI';
        return view('layouts.app' , $data);  
    }
    
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Delete extends Controller
{
    public function Delete()
    {
        return 'Ini Halaman Delete';
    }
}

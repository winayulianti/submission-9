<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Read extends Controller
{
    public function Read()
    {
        return 'Ini Halaman Read';
    }
}

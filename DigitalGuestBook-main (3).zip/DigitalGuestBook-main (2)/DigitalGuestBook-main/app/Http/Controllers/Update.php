<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Update extends Controller
{
    public function Update()
    {
        return 'Ini Halaman Update';
    }
}

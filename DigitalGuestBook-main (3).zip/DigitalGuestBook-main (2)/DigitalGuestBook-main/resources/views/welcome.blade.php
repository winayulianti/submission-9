@extends('layouts.app')

@section('title', 'Halaman Utama')

@section('content')
<div class="container">
    <h1>Selamat Datang </h1>
</div>
@endsection